[ARM Architecture Reference Manual for ARMv8-A 中文解读](http://armv8-ref.codingbelief.com/zh/)
=======

由于 ARM Architecture Reference Manual for ARMv8-A 参考手册 对于一名软件工程师来说，比较晦涩难读，因此在生啃完相关章节后，再用中文注解，方便以后温故。

## 前言

[`英文版`](../../en/preface.html)

This preface introduces the ARM Architecture Reference Manual, ARMv8, for ARMv8-A architecture profile. It contains the following sections:

 * [About this manual on page xvi](#).
 * [Using this manual on page xviii](#).
 * [Conventions on page xxiii](#).
 * [Additional reading on page xxv](#).
 * [Feedback on page xxvi](#).

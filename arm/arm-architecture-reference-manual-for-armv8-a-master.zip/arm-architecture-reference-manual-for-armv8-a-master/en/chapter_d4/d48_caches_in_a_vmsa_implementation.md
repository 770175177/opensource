# D4.8 Caches in a VMSA implementation


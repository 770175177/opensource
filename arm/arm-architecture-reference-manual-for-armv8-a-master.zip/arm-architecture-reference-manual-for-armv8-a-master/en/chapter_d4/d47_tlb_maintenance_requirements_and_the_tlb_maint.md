# D4.7 TLB maintenance requirements and the TLB maintenance instructions


# D4.6 Translation Lookaside Buffers (TLBs)

